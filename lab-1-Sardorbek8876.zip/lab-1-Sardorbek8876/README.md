# Lab 1

Clone this repository to your local computer and make your modifications as given in `lab1.pdf` file. Make sure that you try everything given in `lab1.pdf` file. You can push your folder back to this repository after trying every new cURL command specified in `lab1.pdf` file.
